import sequelize from './config/database.js';
import Instruction from './models/Instruction.js';
import { generateKeywords } from './controllers/aiController.js';

async function fixNullKeywords() {
    try {
        await sequelize.authenticate();
        console.log('Connection has been established successfully.');

        const instructions = await Instruction.findAll({
            where: { keywords: null }
        });

        console.log(`\n🔍 Found ${instructions.length} instructions with NULL keywords.`);

        for (const inst of instructions) {
            console.log(`\n🛠️ Fixing Instruction ID: ${inst.id} | Name: ${inst.clientName}`);
            try {
                // Generate keywords using AI
                // Note: generatedKeywords might return a string or array, aiController usually returns string
                const newKeywords = await generateKeywords(inst.content);

                if (newKeywords) {
                    inst.keywords = newKeywords;
                    await inst.save();
                    console.log(`   ✅ Updated Keywords: ${newKeywords}`);
                } else {
                    console.warn(`   ⚠️ AI returned empty keywords for ID: ${inst.id}`);
                }
            } catch (err) {
                console.error(`   ❌ Error fixing ID ${inst.id}:`, err.message);
            }
            // Small delay to avoid rate limits
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        console.log('\n✅ Fix Complete.');

    } catch (error) {
        console.error('Database connection failed:', error);
    } finally {
        await sequelize.close();
    }
}

fixNullKeywords();
