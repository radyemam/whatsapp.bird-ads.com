import express from 'express';
import { startSession, stopSession, logoutSession, getStatus, getGroups } from '../controllers/botController.js';
import User from '../models/User.js';
import Message from '../models/Message.js';
import Instruction from '../models/Instruction.js';
import { upload, compressAndSaveImage, deleteImage } from '../config/uploadConfig.js';

const router = express.Router();

// Middleware to ensure login
const isAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) return next();
    res.redirect('/login');
};

router.use(isAuthenticated);

router.get('/', async (req, res) => {
    if (req.user.role === 'super_admin') {
        return res.redirect('/admin');
    }
    const statusResult = await getStatus(req.user.id);
    res.render('user_dashboard', {
        user: req.user,
        status: statusResult.status || 'offline',
        phone: statusResult.phone || '',
        page: 'home'
    });
});

router.get('/chats', async (req, res) => {
    try {
        // Fetch unique contacts
        const contacts = await Message.findAll({
            where: { UserId: req.user.id },
            attributes: ['remoteJid'],
            group: ['remoteJid']
        });

        // Fetch requested chat messages if 'jid' query is present
        let messages = [];
        let activeJid = req.query.jid || null;

        if (activeJid) {
            messages = await Message.findAll({
                where: { UserId: req.user.id, remoteJid: activeJid },
                order: [['createdAt', 'ASC']]
            });
        }

        res.render('chats', { user: req.user, page: 'chats', contacts, messages, activeJid });
    } catch (err) {
        console.error(err);
        res.status(500).send("Error fetching chats");
    }
});

router.post('/start-bot', async (req, res) => {
    const io = req.app.get('socketio');
    const result = await startSession(req.user.id, io);
    res.json(result);
});

router.post('/pair-bot', async (req, res) => {
    const { phoneNumber } = req.body;
    const io = req.app.get('socketio');
    const result = await startSession(req.user.id, io, phoneNumber);
    res.json(result);
});

router.post('/stop-bot', async (req, res) => {
    const io = req.app.get('socketio');
    const result = await stopSession(req.user.id, io);
    res.json(result);
});

router.post('/logout-bot', async (req, res) => {
    const io = req.app.get('socketio');
    const result = await logoutSession(req.user.id, io);
    res.json(result);
});

router.get('/groups', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const groups = await getGroups(req.user.id, page);
        res.json(groups);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to fetch groups' });
    }
});

// Instructions CRUD
router.get('/instructions', async (req, res) => {
    try {
        const instructions = await Instruction.findAll({
            where: { UserId: req.user.id },
            order: [['order', 'ASC'], ['createdAt', 'DESC']]
        });

        // Groups fetch removed to prevent hanging. Groups can be loaded via AJAX if needed.
        const groups = [];
        res.render('instructions', { user: req.user, page: 'instructions', instructions, groups, success: false });
    } catch (err) {
        console.error(err);
        res.status(500).send("Error fetching instructions");
    }
});

import { analyzeAndSegmentText, generateKeywords } from '../controllers/aiController.js';

// ... (existing imports)

router.post('/instructions/add', async (req, res) => {
    try {
        const { clientName, content, actionTarget, imageUrl } = req.body;

        // 1. AI Analysis & Segmentation
        console.log("🧠 Analyzing instruction text...");
        const segments = await analyzeAndSegmentText(content);
        console.log(`✅ AI Segmentation Result: ${segments.length} segments.`);

        // 2. Create Instructions based on segments
        for (const segment of segments) {
            await Instruction.create({
                UserId: req.user.id,
                clientName: segment.clientName || clientName, // Use AI suggested name or fallback to user input
                title: segment.clientName || clientName,
                content: segment.content,
                keywords: segment.keywords || "", // Ensure keywords are saved
                type: segment.type || 'topic',    // 'global' or 'topic'
                actionTarget: actionTarget || null, // Preserve original target
                imageUrl: imageUrl || null          // Preserve original image
            });
        }

        const instructions = await Instruction.findAll({
            where: { UserId: req.user.id },
            order: [['order', 'ASC'], ['createdAt', 'DESC']]
        });

        res.render('instructions', { user: req.user, page: 'instructions', instructions, success: true });
    } catch (err) {
        console.error(err);
        res.status(500).send("Error adding instruction");
    }
});

// ... (existing routes)

// Toggle Instruction Status
router.post('/instructions/toggle/:id', async (req, res) => {
    try {
        const instruction = await Instruction.findOne({ where: { id: req.params.id, UserId: req.user.id } });
        if (instruction) {
            instruction.isActive = !instruction.isActive;
            await instruction.save();
        }
        res.redirect('/dashboard/instructions');
    } catch (err) {
        console.error(err);
        res.status(500).send("Error toggling instruction");
    }
});

router.post('/instructions/delete', async (req, res) => {
    try {
        const { id } = req.body;
        await Instruction.destroy({
            where: { id, UserId: req.user.id }
        });
        res.redirect('/dashboard/instructions');
    } catch (err) {
        console.error(err);
        res.status(500).send("Error deleting instruction");
    }
});

router.post('/instructions/edit', async (req, res) => {
    try {
        const { id, clientName, content, actionTarget, imageUrl } = req.body;

        // 1. Regenerate Keywords (AI) for the updated content
        // We assume editing does NOT re-segment, just updates the single block.
        console.log("🧠 Regenerating keywords for edit...");
        const newKeywords = await generateKeywords(content);

        await Instruction.update(
            {
                clientName,
                content,
                keywords: newKeywords, // Update keywords
                actionTarget: actionTarget || null,
                imageUrl: imageUrl || null
            },
            { where: { id, UserId: req.user.id } }
        );
        res.redirect('/dashboard/instructions');
    } catch (err) {
        console.error(err);
        res.status(500).send("Error updating instruction");
    }
});

router.post('/chats/delete', async (req, res) => {
    try {
        const { remoteJid } = req.body;
        await Message.destroy({
            where: {
                remoteJid,
                UserId: req.user.id
            }
        });
        res.redirect('/dashboard/chats');
    } catch (err) {
        console.error(err);
        res.status(500).send("Error deleting chat");
    }
});

// Profile Routes
router.get('/profile', (req, res) => {
    res.render('profile', { user: req.user, page: 'profile' });
});

router.post('/profile/password', async (req, res) => {
    try {
        const { currentPassword, newPassword, confirmPassword } = req.body;

        if (newPassword !== confirmPassword) {
            return res.render('profile', { user: req.user, page: 'profile', error: 'كلمة المرور الجديدة غير متطابقة!' });
        }

        const user = await User.findByPk(req.user.id);
        const isValid = await user.validPassword(currentPassword);

        if (!isValid) {
            return res.render('profile', { user: req.user, page: 'profile', error: 'كلمة المرور الحالية غير صحيحة!' });
        }

        user.password = newPassword;
        await user.save(); // Hooks will hash it

        res.render('profile', { user: req.user, page: 'profile', success: true });
    } catch (err) {
        console.error(err);
        res.status(500).send("Error updating password");
    }
});


// Privacy Policy Route
router.get('/privacy', (req, res) => {
    res.render('privacy_policy', { user: req.user, page: 'privacy' });
});

// Image Upload Routes
router.post('/instructions/upload-image', upload.single('image'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No image uploaded' });
        }

        // Compress and save image
        const imageUrl = await compressAndSaveImage(req.file);

        res.json({ imageUrl });
    } catch (err) {
        console.error('Upload error:', err);
        res.status(500).json({ error: 'Failed to upload image' });
    }
});

router.post('/instructions/delete-image', async (req, res) => {
    try {
        const { imageUrl } = req.body;
        deleteImage(imageUrl);
        res.json({ success: true });
    } catch (err) {
        console.error('Delete error:', err);
        res.status(500).json({ error: 'Failed to delete image' });
    }
});

export default router;
