import { CONFIG } from '../config.js';

// Helper to call Gemini API for segmentation and keywords
// We reuse the Vertex AI/Gemini endpoint configuration from config.js

async function callGeminiForAnalysis(prompt) {
    const url = `https://us-central1-aiplatform.googleapis.com/v1/projects/${CONFIG.PROJECT_ID}/locations/us-central1/publishers/google/models/${CONFIG.MODEL_NAME}:generateContent?key=${CONFIG.USER_KEY}`;

    const payload = {
        contents: [{
            role: "user",
            parts: [{ text: prompt }]
        }],
        generationConfig: {
            temperature: 0.2, // Low temperature for consistent formatting
            topP: 0.8,
            topK: 40
        }
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const errText = await response.text();
            throw new Error(`Gemini Analysis Error ${response.status}: ${errText}`);
        }

        const data = await response.json();
        return data.candidates?.[0]?.content?.parts?.[0]?.text || null;
    } catch (error) {
        console.error("AI Analysis Failed:", error);
        return null;
    }
}

export const analyzeAndSegmentText = async (text) => {
    // Prompt to split text into logical segments with keywords
    const prompt = `
    أنت مساعد ذكي لتنظيم البيانات.
    قم بتحليل النص التالي وتقسيمه إلى أجزاء وتصنيفات منطقية (مثل: الأسعار، طرق الدفع، العنوان، المقدمة، الخاتمة، الشرح، إلخ).
    
    النص:
    """
    ${text}
    """

    المطلوب:
    1. قسم النص إلى فقرات أو مواضيع مستقلة.
    2. لكل قسم، استخرج 5-10 كلمات مفتاحية (Keywords) باللهجة المصرية والعربية تعبر عن محتوى القسم (وتشمل المرادفات المحتملة التي قد يسأل عنها العميل).
    3. حدد نوع القسم: "global" (للترحيب، الخاتمة، الهوية الأساسية - يظهر دايماً) أو "topic" (للأسعار، التفاصيل، الشرح - يظهر عند الطلب).
    
    الرد يجب أن يكون **فقط** بصيغة JSON Array كالتالي بدون أيmarkdown:
    [
        {
            "clientName": "اسم مختصر للقسم (مثال: الأسعار)",
            "content": "نص القسم كاملاً",
            "keywords": "سعر, بكام, مصاريف, دفع, فودافون",
            "type": "topic"
        },
        ...
    ]
    `;

    const resultText = await callGeminiForAnalysis(prompt);

    try {
        // Clean markdown code blocks if present
        const cleaned = resultText.replace(/```json/g, '').replace(/```/g, '').trim();
        return JSON.parse(cleaned);
    } catch (e) {
        console.error("Failed to parse AI Segmentation JSON:", e);
        // Fallback: Return original text as one block
        return [{
            clientName: "تعليمات عامة",
            content: text,
            keywords: "عام, تفاصيل, معلومات",
            type: "global"
        }];
    }
};

export const generateKeywords = async (text) => {
    const prompt = `
    استخرج 10 كلمات مفتاحية (Tags) تعبر عن النص التالي لاستخدامها في البحث.
    الكلمات يجب أن تكون باللهجة المصرية والعربية، وتشمل المرادفات.
    
    النص: "${text}"
    
    الرد مطلوب بصيغة نصية مفصولة بفواصل فقط (مثال: سعر, بكام, تكلفة) بدون أي شرح أو كلام إضافي.
    `;

    const result = await callGeminiForAnalysis(prompt);
    return result ? result.trim() : "";
};
